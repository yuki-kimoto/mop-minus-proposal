package Role1 {
  use mop::minus;

  sub foo {
    return 'foo';
  }
}

1;
