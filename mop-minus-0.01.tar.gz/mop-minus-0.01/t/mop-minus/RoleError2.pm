package RoleError2 {
  use mop::minus;
  with Role1;
}
