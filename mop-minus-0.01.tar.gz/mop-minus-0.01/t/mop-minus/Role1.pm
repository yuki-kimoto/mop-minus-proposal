package Role1 {
  use mop::minus;

  sub role1_method1 {
    return 'role1_method1';
  }

  sub same_method1 {
    return 'role1_same_method1';
  }
}

1;
