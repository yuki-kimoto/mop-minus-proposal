package T2 {
  use mop::minus;

  has x = 1;
  has y = 2;
}
