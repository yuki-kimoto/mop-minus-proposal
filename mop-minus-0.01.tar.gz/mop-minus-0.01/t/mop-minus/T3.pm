package T3 {
  use mop::minus;
  
  extends T2;

  has z = 3;
}
