package RoleError1 {
  use mop::minus;
  extends T1;
}
