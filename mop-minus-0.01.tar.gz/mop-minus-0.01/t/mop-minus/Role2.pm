package Role2 {
  use mop::minus;

  sub role2_method1 {
    return 'role2_method1';
  }

  sub same_method1 {
    return 'role2_same_method1';
  }
}

1;
