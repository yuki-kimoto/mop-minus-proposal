package T3_2 {
  use mop::minus;
  
  extends T2;
  
  has z = 3;
}
