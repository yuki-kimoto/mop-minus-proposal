package Role1 {
  use mop::minus;
  
  # will be "method foo { ... }"
  sub foo {
    return 'foo';
  }
}
