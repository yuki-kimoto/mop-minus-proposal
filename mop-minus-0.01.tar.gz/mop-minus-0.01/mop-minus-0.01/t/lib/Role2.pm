package Role2 {
  use mop::minus;

  sub bar {
    return 'bar';
  }
}

1;
